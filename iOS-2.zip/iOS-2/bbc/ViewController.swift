//
//  ViewController.swift
//  bbc
//
//  Created by ANYELLA VALERIA PEREZ BUENDIA on 29/02/20.
//  Copyright © 2020 ANYELLA VALERIA PEREZ BUENDIA. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var orders = ["order 1", "order 1", "order 1", "order 1", "order 1"]
    var ordersItems = ["1 jar Cajica", "5 jars Cajica", "1 jar Monserrate", "1 jar Lager", "3 jars Cajica", ]
    
    @IBOutlet weak var usernameTextfield: UITextField!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var passwordTextfield: UITextField!
    override func viewDidLoad(){
        var purpleBorderColor = UIColor(red:152.0/255.0, green:100.0/255.0, blue: 128.0/255.0, alpha:1.0)
        passwordTextfield.layer.borderColor = purpleBorderColor.cgColor
        usernameTextfield.layer.borderColor = purpleBorderColor.cgColor
        super.viewDidLoad()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

}
extension ViewController: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return orders.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        as? OrderTableViewCell
        return cell!
    }
}

