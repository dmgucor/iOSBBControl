//
//  Beer.swift
//  bbc
//
//  Created by DIANA MARCELA GUTIERREZ CORDOBA on 29/02/20.
//  Copyright © 2020 ANYELLA VALERIA PEREZ BUENDIA. All rights reserved.
//

import UIKit

class Beer {
    //MARK: Properties
    
    var name: String
    var price: String
    var photo: UIImage?
    
    //MARK: Initialization
     
    init?(name: String, price: String, photo: UIImage?) {
        self.name = name
        self.price = price
        self.photo  = photo
    }
}
