//
//  CustomCell.swift
//  bbc
//
//  Created by ANYELLA VALERIA PEREZ BUENDIA on 13/03/20.
//  Copyright © 2020 ANYELLA VALERIA PEREZ BUENDIA. All rights reserved.
//

import Foundation
import UIKit

class CustomCell: UITableViewCell{
    
   /*var message : String?
    var imageBacata: UIImageView?
    
    var messageView : UITextView = {
        
        var textView :  UITextView
        textView.translatesAutoresizingMaskIntoConstraints = false
        return textView
        
    }()
    
override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }*/
    
    
    
}
