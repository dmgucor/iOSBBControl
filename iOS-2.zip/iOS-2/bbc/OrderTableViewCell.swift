//
//  OrderTableViewCell.swift
//  bbc
//
//  Created by DIANA MARCELA GUTIERREZ CORDOBA on 29/02/20.
//  Copyright © 2020 ANYELLA VALERIA PEREZ BUENDIA. All rights reserved.
//

import UIKit

class OrderTableViewCell: UITableViewCell {
    
    @IBOutlet weak var table: UILabel!
    @IBOutlet weak var status: UILabel!
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBOutlet weak var tableView: UITableView!
    

}
